// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode with RLE\n", stdout);
  return lionss_run_workload("ColumnarEncode");
}
