// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode hybrid lossless"); }
int main(){
  announce();
  return lionss_run_workload("wavpackHybrid");
}
